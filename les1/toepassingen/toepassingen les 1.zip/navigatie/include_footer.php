<footer>
            <p>Fixed footer</p>
</footer>